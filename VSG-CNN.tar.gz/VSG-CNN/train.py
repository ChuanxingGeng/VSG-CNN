import torch
import torch.optim as optim
from torch.utils.data import Dataset
import numpy as np
import argparse
import json

from dataset import GBU_Dataset
from utils import *
from model import deepnet, ShallowNet

parser = argparse.ArgumentParser(description='Co-Representation Learning for GBU Dataset')
opt = parser.parse_args()
opt.batch_size = 128
opt.test_batch_size = 256
opt.weight_l1 = 0
opt.weight_l2 = 0
opt.log_interval = 20
opt.manualSeed = 0
opt.num_workers = 8
opt.checkpoints = 'checkpoints'
opt.repeat_times = 1
opt.co = True  # co or non-co
opt.deep = True  # deep or shallow
opt.osr = False

opt.dataset = 'awa'
if opt.dataset == 'cub':
    opt.epochs, opt.step_size, opt.gamma = 60, 45, 0.1
    opt.lr, opt.relr = 0.005, 1.15
    opt.prototype_dim, opt.weight_pl = 256, 1
    if opt.osr:
        opt.prototype_dim, opt.weight_pl = 256, 10
elif opt.dataset == 'awa':
    opt.epochs, opt.step_size, opt.gamma = 20, 10, 0.1
    opt.lr, opt.relr = 0.0004, 1.15
    opt.prototype_dim, opt.weight_pl = 85, 1
    if opt.osr:
        opt.prototype_dim, opt.weight_pl = 64, 1
elif opt.dataset == 'apy':
    opt.epochs, opt.step_size, opt.gamma = 30, 20, 0.1
    opt.lr, opt.relr = 0.0001, 4
    opt.prototype_dim, opt.weight_pl = 85, 1
    if opt.osr:
        opt.prototype_dim, opt.weight_pl = 85, 10
elif opt.dataset == 'sun':
    opt.epochs, opt.step_size, opt.gamma = 30, 20, 0.1
    opt.lr, opt.relr = 0.001, 2
    opt.prototype_dim, opt.weight_pl = 312, 1
    if opt.osr:
        opt.prototype_dim, opt.weight_pl = 717, 0.1

if opt.deep:
    net = deepnet
else:
    net = ShallowNet
opt.threshold_filename = '{}/{}_{}_{}_threshold.tar'.format(opt.checkpoints, 'deep' if opt.deep else 'shallow',
                                                            'co' if opt.co else 'no', opt.dataset)
opt.model_filename = '{}/{}_{}_{}.tar'.format(opt.checkpoints, 'deep' if opt.deep else 'shallow',
                                              'co' if opt.co else 'no', opt.dataset)
opt.sensitivity_filename = '{}/{}_{}_{}.csv'.format(opt.checkpoints, 'deep' if opt.deep else 'shallow',
                                                    'co' if opt.co else 'no', opt.dataset)

print('Running parameters: ')
print(json.dumps(vars(opt), indent=4, separators=(',', ':')))

if opt.manualSeed is None:
    opt.manualSeed = random.randint(1, 10000)
print("Random Seed: ", opt.manualSeed)
np.random.seed(opt.manualSeed)
torch.manual_seed(opt.manualSeed)
torch.cuda.manual_seed_all(opt.manualSeed)

device = torch.device('cuda')


def train(model, visual_prototype, semantic_prototype, dataloader, optimizer, epoch):
    model.train()
    for batch_idx, sample in enumerate(dataloader):
        image = sample['feature'].to(device=device, dtype=torch.float)
        label = sample['label'].to(device=device, dtype=torch.int64)
        
        optimizer.zero_grad()
        visual, semantic = model(image)
        loss = co_loss(visual, semantic, visual_prototype, semantic_prototype, label, opt)
        loss.backward()
        optimizer.step()
        
        if batch_idx % opt.log_interval == 0:
            print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
                epoch, batch_idx * dataloader.batch_size, len(dataloader.dataset), 100. * batch_idx / len(dataloader),
                loss.item()
            ))


def test(model, visual_prototype, semantic_prototype, dataloader):
    model.eval()
    test_loss = 0
    visual_correct = 0
    semantic_correct = 0
    with torch.no_grad():
        for sample in dataloader:
            image = sample['feature'].to(device=device, dtype=torch.float)
            label = sample['label'].to(device=device, dtype=torch.int64)
            visual, semantic = model(image)
            loss = co_loss(visual, semantic, visual_prototype, semantic_prototype, label, opt)
            
            test_loss += loss.item()
            visual_logits = -euclidean_metric(visual, visual_prototype)
            semantic_logits = -euclidean_metric(semantic, semantic_prototype)
            visual_correct += count_acc(visual_logits.detach(), label.detach())
            semantic_correct += count_acc(semantic_logits.detach(), label.detach())
        test_loss /= len(dataloader)
    
    print('\tTest set: Average loss: {:.4f}, Feat accuracy: {}/{} ({:.2f}%), Attr accuracy: {}/{} ({:.2f}%)\n'.format(
        test_loss, visual_correct, len(dataloader.dataset), 100. * visual_correct / len(dataloader.dataset),
        semantic_correct, len(dataloader.dataset), 100. * semantic_correct / len(dataloader.dataset)
    ))
    return visual_correct / len(dataloader.dataset)


def train_for_threshold():
    datasets = {
        'train_seen': GBU_Dataset(dataset=opt.dataset, mode='train_for_threshold', get_image=opt.deep,
                                  image_transform=data_transforms['train']),
        'val_seen': GBU_Dataset(dataset=opt.dataset, mode='val_for_threshold', get_image=opt.deep,
                                image_transform=data_transforms['test']),
    }
    dataloaders = {
        'train_seen': torch.utils.data.DataLoader(datasets['train_seen'], batch_size=opt.batch_size, shuffle=True,
                                                  pin_memory=True, num_workers=opt.num_workers),
        'val_seen': torch.utils.data.DataLoader(datasets['val_seen'], batch_size=opt.test_batch_size, shuffle=False,
                                                pin_memory=True, num_workers=opt.num_workers),
    }
    model = net(visual_dim=opt.prototype_dim, semantic_dim=datasets['train_seen'].attribute_dim, co=opt.co,
                pretrained=True)
    set_trainable(model, ['visual', 'semantic', 'shared'])
    model = model.to(device)
    visual_prototype = torch.rand(datasets['train_seen'].prototype_num_for_threshold, opt.prototype_dim).to(device)
    semantic_prototype = torch.from_numpy(datasets['train_seen'].attribute['train']).to(device=device,
                                                                                        dtype=torch.float)
    visual_prototype.requires_grad = True
    semantic_prototype.requires_grad = False
    
    params_to_update_1 = get_trainable(model, keyword='visual')
    params_to_update_2 = get_trainable(model, keyword='semantic')
    params_to_update_3 = get_trainable(model, keyword='shared')

    optimizer = optim.SGD([
        {'params': params_to_update_1, 'weight_decay': opt.weight_l2},
        {'params': params_to_update_2, 'lr': opt.lr * opt.relr, 'weight_decay': opt.weight_l2},
        {'params': params_to_update_3, 'lr': opt.lr * opt.relr, 'weight_decay': opt.weight_l2},
        {'params': visual_prototype},
    ], lr=opt.lr, momentum=0.9)

    # optimizer = optim.Adam([
    #     {'params': params_to_update_1, 'weight_decay': opt.weight_l2},
    #     {'params': params_to_update_2, 'lr': opt.lr * opt.relr, 'weight_decay': opt.weight_l2},
    #     {'params': params_to_update_3, 'lr': opt.lr * opt.relr, 'weight_decay': opt.weight_l2},
    #     {'params': visual_prototype},
    # ], lr=opt.lr)

    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=opt.step_size, gamma=opt.gamma)
    best_acc = 0
    for epoch in range(1, opt.epochs + 1):
        scheduler.step()
        train(model, visual_prototype, semantic_prototype, dataloaders['train_seen'], optimizer, epoch)
        acc = test(model, visual_prototype, semantic_prototype, dataloaders['val_seen'])
        if acc > best_acc:
            best_acc = acc
            torch.save({
                'model_state_dict': model.state_dict(),
                'prototype': visual_prototype,
                'best_acc': best_acc,
            }, opt.threshold_filename)


def train_for_gzsl():
    datasets = {
        'train_seen': GBU_Dataset(dataset=opt.dataset, mode='train_for_gzsl', get_image=opt.deep,
                                  image_transform=data_transforms['train']),
        'val_seen': GBU_Dataset(dataset=opt.dataset, mode='val_for_gzsl', get_image=opt.deep,
                                image_transform=data_transforms['test']),
        'test_unseen': GBU_Dataset(dataset=opt.dataset, mode='test_unseen', get_image=opt.deep,
                                   image_transform=data_transforms['test']),
    }
    dataloaders = {
        'train_seen': torch.utils.data.DataLoader(datasets['train_seen'], batch_size=opt.batch_size, shuffle=True,
                                                  pin_memory=True, num_workers=opt.num_workers),
        'val_seen': torch.utils.data.DataLoader(datasets['val_seen'], batch_size=opt.test_batch_size, shuffle=False,
                                                pin_memory=True, num_workers=opt.num_workers),
        'test_unseen': torch.utils.data.DataLoader(datasets['test_unseen'], batch_size=opt.test_batch_size,
                                                   shuffle=False, pin_memory=True, num_workers=opt.num_workers),
    }
    model = net(visual_dim=opt.prototype_dim, semantic_dim=datasets['train_seen'].attribute_dim, co=opt.co,
                pretrained=True)
    set_trainable(model, ['visual', 'semantic', 'shared'])
    model = model.to(device)
    visual_prototype = torch.rand(datasets['train_seen'].prototype_num, opt.prototype_dim).to(device)
    semantic_prototype = torch.from_numpy(datasets['train_seen'].attribute['trainval']).to(device=device,
                                                                                           dtype=torch.float)
    visual_prototype.requires_grad = True
    semantic_prototype.requires_grad = False
    
    params_to_update_1 = get_trainable(model, keyword='visual')
    params_to_update_2 = get_trainable(model, keyword='semantic')
    params_to_update_3 = get_trainable(model, keyword='shared')

    optimizer = optim.SGD([
        {'params': params_to_update_1, 'weight_decay': opt.weight_l2},
        {'params': params_to_update_2, 'lr': opt.lr * opt.relr, 'weight_decay': opt.weight_l2},
        {'params': params_to_update_3, 'lr': opt.lr * opt.relr, 'weight_decay': opt.weight_l2},
        {'params': visual_prototype},
    ], lr=opt.lr, momentum=0.9)

    # optimizer = optim.Adam([
    #     {'params': params_to_update_1, 'weight_decay': opt.weight_l2},
    #     {'params': params_to_update_2, 'lr': opt.lr * opt.relr, 'weight_decay': opt.weight_l2},
    #     {'params': params_to_update_3, 'lr': opt.lr * opt.relr, 'weight_decay': opt.weight_l2},
    #     {'params': visual_prototype},
    # ], lr=opt.lr)

    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=opt.step_size, gamma=opt.gamma)
    best_acc = 0
    for epoch in range(1, opt.epochs + 1):
        scheduler.step()
        train(model, visual_prototype, semantic_prototype, dataloaders['train_seen'], optimizer, epoch)
        acc = test(model, visual_prototype, semantic_prototype, dataloaders['val_seen'])
        if acc > best_acc:
            best_acc = acc
            torch.save({
                'model_state_dict': model.state_dict(),
                'prototype': visual_prototype,
                'best_acc': best_acc,
            }, opt.model_filename)


def find_threshold(model, prototype, loader_seen, loader_unseen):
    thresholds = np.linspace(0, 0.02, 10000)
    AR, RR, H, thresholds = entropy_rejection(model, prototype, loader_seen, loader_unseen, thresholds, device)
    idx_max = np.argmax(H)
    best_threshold = thresholds[idx_max]
    
    print('\n|Thresholds:\t\t\t|', '|'.join('{:.4f}'.format(i) for i in thresholds))
    print('|**Acceptance rate**\t|', '|'.join('{:.4f}'.format(i) for i in AR))
    print('|**Rejection rate**\t\t|', '|'.join('{:.4f}'.format(i) for i in RR))
    print('|**H**\t\t\t\t\t|', '|'.join('{:.4f}'.format(i) for i in H))
    print('Best: |{:.6f}|{:.6f}|{:.6f}|{:.6f}|'.format(thresholds[idx_max], AR[idx_max], RR[idx_max],
                                                       H[idx_max]))
    return AR[idx_max], RR[idx_max], H[idx_max], best_threshold


def evaluate():
    datasets = {
        'val_seen': GBU_Dataset(dataset=opt.dataset, mode='val_for_threshold', get_image=opt.deep,
                                image_transform=data_transforms['test']),
        'val_unseen': GBU_Dataset(dataset=opt.dataset, mode='val', get_image=opt.deep,
                                  image_transform=data_transforms['test']),
        'test_seen': GBU_Dataset(dataset=opt.dataset, mode='test_seen', get_image=opt.deep,
                                 image_transform=data_transforms['test']),
        'test_unseen': GBU_Dataset(dataset=opt.dataset, mode='test_unseen', get_image=opt.deep,
                                   image_transform=data_transforms['test']),
    }
    dataloaders = {
        'val_seen': torch.utils.data.DataLoader(datasets['val_seen'], batch_size=opt.test_batch_size, shuffle=False,
                                                pin_memory=True, num_workers=opt.num_workers),
        'val_unseen': torch.utils.data.DataLoader(datasets['val_unseen'], batch_size=opt.test_batch_size, shuffle=False,
                                                  pin_memory=True, num_workers=opt.num_workers),
        'test_seen': torch.utils.data.DataLoader(datasets['test_seen'], batch_size=opt.test_batch_size, shuffle=False,
                                                 pin_memory=True, num_workers=opt.num_workers),
        'test_unseen': torch.utils.data.DataLoader(datasets['test_unseen'], batch_size=opt.test_batch_size,
                                                   shuffle=False, pin_memory=True, num_workers=opt.num_workers),
    }
    model = net(visual_dim=opt.prototype_dim, semantic_dim=datasets['val_seen'].attribute_dim, co=opt.co,
                pretrained=True)
    model = model.to(device)
    model_tar = torch.load(opt.threshold_filename)
    model.load_state_dict(model_tar['model_state_dict'])
    visual_prototype = model_tar['prototype']
    print('\tModel file: ', opt.threshold_filename)
    print('\tBest Accurancy: ', model_tar['best_acc'])
    _, _, _, best_threshold = find_threshold(model, visual_prototype, dataloaders['val_seen'],
                                             dataloaders['val_unseen'])
    model_tar = torch.load(opt.model_filename)
    model.load_state_dict(model_tar['model_state_dict'])
    visual_prototype = model_tar['prototype']
    print('\tModel file: ', opt.threshold_filename)
    print('\tBest Accurancy: ', model_tar['best_acc'])
    _, _, _, optimal_threshold = find_threshold(model, visual_prototype, dataloaders['test_seen'],
                                                dataloaders['test_unseen'])

    zsl = zsl_acc(model, dataloaders['test_unseen'], device)
    normal = normal_acc(model, visual_prototype, dataloaders['test_seen'], device)
    
    seen_acc, AR, _ = gzsl_acc(optimal_threshold, model, visual_prototype, dataloaders['test_seen'], device)
    unseen_acc, _, _ = gzsl_acc(optimal_threshold, model, visual_prototype, dataloaders['test_unseen'], device)
    H_optim = 2 * seen_acc * unseen_acc / (seen_acc + unseen_acc)
    
    seen_acc, AR, _ = gzsl_acc(best_threshold, model, visual_prototype, dataloaders['test_seen'], device)
    unseen_acc, _, RR = gzsl_acc(best_threshold, model, visual_prototype, dataloaders['test_unseen'], device)
    H = 2 * seen_acc * unseen_acc / (seen_acc + unseen_acc)  # For GZSL
    F1 = 2 * seen_acc * RR / (seen_acc + RR)  # For OSR
    
    return best_threshold, optimal_threshold, AR, RR, seen_acc, unseen_acc, H, H_optim, F1, normal, zsl


def main():
    import time
    import datetime
    start = time.time()
    
    print('=====> Training model for threshold')
    train_for_threshold()
    print('=====> Training model for gzsl')
    train_for_gzsl()
    print('\n=====> Evaluating model')
    results = evaluate()
    
    end = time.time()
    time_consumed = str(datetime.timedelta(seconds=end - start))
    
    best_th, optimal_th, AR, RR, seen_acc, unseen_acc, H, H_optim, F1, normal, zsl = results
    print('=====> Time consumed: {}'.format(time_consumed))
    print('=====> opt.prototype_dim: {}, opt.weight_pl: {}'.format(opt.prototype_dim, opt.weight_pl))
    print('\tAverage_th/Optimal_th, AR, RR, seen_acc, unseen_acc, H/H_optim, F1, Normal_acc, ZSL_acc: '
          '|{:.6f} / {:.6f}|{:.6f}|{:.6f}|{:.6f}|{:.6f}|{:.6f} / {:.6f}|{:.6f}|{:.6f}|{:.6f}|'.format(
        best_th, optimal_th, AR, RR, seen_acc, unseen_acc, H, H_optim, F1, normal, zsl))
    return results


def sensitivity_analysis():
    datasets = {
        'test_seen': GBU_Dataset(dataset=opt.dataset, mode='test_seen', get_image=opt.deep,
                                 image_transform=data_transforms['test']),
        'test_unseen': GBU_Dataset(dataset=opt.dataset, mode='test_unseen', get_image=opt.deep,
                                   image_transform=data_transforms['test']),
    }
    dataloaders = {
        'test_seen': torch.utils.data.DataLoader(datasets['test_seen'], batch_size=opt.test_batch_size, shuffle=False,
                                                 pin_memory=True, num_workers=opt.num_workers),
        'test_unseen': torch.utils.data.DataLoader(datasets['test_unseen'], batch_size=opt.test_batch_size,
                                                   shuffle=False, pin_memory=True, num_workers=opt.num_workers),
    }
    model = net(visual_dim=opt.prototype_dim, semantic_dim=datasets['test_seen'].attribute_dim, co=opt.co,
                pretrained=True)
    model = model.to(device)
    model_tar = torch.load(opt.model_filename)
    model.load_state_dict(model_tar['model_state_dict'])
    visual_prototype = model_tar['prototype']
    print('\tModel file: ', opt.threshold_filename)
    print('\tBest Accurancy: ', model_tar['best_acc'])

    # thresholds = np.linspace(0, 0.02, 10000)
    # thresholds = np.linspace(0, 0.005, 2500)
    # thresholds = np.linspace(0.005, 0.01, 2500)
    # thresholds = np.linspace(0.01, 0.015, 2500)
    thresholds = np.linspace(0.015, 0.02, 2500)

    seen_accuracy, seen_accept, _ = entropy_analysis(model, visual_prototype, dataloaders['test_seen'],
                                                     thresholds, device, is_seen=True)
    unseen_accuracy, _, unseen_reject = entropy_analysis(model, visual_prototype, dataloaders['test_unseen'],
                                                         thresholds, device, is_seen=False)
    
    func = '{:.6f}'.format
    headers = ['threshold', 'seen_accept', 'unseen_reject', 'seen_accuracy', 'unseen_accuracy', 'H']
    rows = []
    Hs = []
    for i, threshold in enumerate(thresholds):
        H = 2 * seen_accuracy[i] * unseen_accuracy[i] / (seen_accuracy[i] + unseen_accuracy[i])
        Hs.append(H)
        row = (func(threshold), func(seen_accept[i]), func(unseen_reject[i]),
               func(seen_accuracy[i]), func(unseen_accuracy[i]), func(H))
        rows.append(row)
    import csv
    with open(opt.sensitivity_filename, 'w') as f:
        f_csv = csv.writer(f)
        f_csv.writerow(headers)
        f_csv.writerows(rows)
        
    print('Max H: ', func(max(Hs)))
    return max(Hs)
    

if __name__ == '__main__':
    main()
    # sensitivity_analysis()

# all_results = []
# for i in range(opt.repeat_times):
# 	results = main()
# 	all_results.append(results)
# print('\n\n')
# for i in range(opt.repeat_times):
# 	best_th, optimal_th, AR, RR, seen_acc, unseen_acc, H, H_optim, F1, normal, zsl = \
# 		all_results[i]
# 	print('=====> opt.prototype_dim: {}, opt.weight_pl: {}'.format(opt.prototype_dim, opt.weight_pl))
# 	print('\tAverage_th/Optimal_th, AR, RR, seen_acc, unseen_acc, H/H_optim, F1, Normal_acc, ZSL_acc: '
# 		  '|{}\t|{:.6f} / {:.6f}|{:.6f}|{:.6f}|{:.6f}|{:.6f}|{:.6f} / {:.6f}|{:.6f}|{:.6f}|{:.6f}|{} |'.format(
# 		opt.dataset.upper(), best_th, optimal_th, AR, RR, seen_acc, unseen_acc, H, H_optim, F1, normal, zsl, opt.prototype_dim))

# prodims = [32, 50, 64, 85, 102, 128, 200, 256, 312, 512, 717]
# weights = [0.0001, 0.001, 0.01, 0.1, 1, 10]
#
# prodims = [85, 256, 384]
# weights = [1, 1]
#
# all_results = []
# for w in weights:
# 	opt.weight_pl = w
# 	for d in prodims:
# 		opt.prototype_dim = d
# 		results = main()
# 		all_results.append(results)
#
# print('\n\n')
# idx = 0
# for w in weights:
# 	for d in prodims:
# 		best_th, optimal_th, AR, RR, seen_acc, unseen_acc, H, H_optim, F1, normal, zsl = \
# 			all_results[idx]
# 		idx += 1
# 		print('=====> opt.prototype_dim: {}, opt.weight_pl: {}'.format(d, w))
# 		print('\tAverage_th/Optimal_th, AR, RR, seen_acc, unseen_acc, H/H_optim, F1, Normal_acc, ZSL_acc: '
# 			  '|{}\t|{:.6f} / {:.6f}|{:.6f}|{:.6f}|{:.6f}|{:.6f}|{:.6f} / {:.6f}|{:.6f}|{:.6f}|{:.6f}|{} |'.format(
# 			opt.dataset.upper(), best_th, optimal_th, AR, RR, seen_acc, unseen_acc, H, H_optim, F1, normal, zsl, d))
