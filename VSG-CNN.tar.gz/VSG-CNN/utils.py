import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import transforms
import numpy as np
import random
from tqdm import tqdm


def get_train_val_split(lenth, weight):
	idx = np.linspace(0, lenth-1, lenth).astype(int)
	np.random.seed(0)
	np.random.shuffle(idx)
	train_split = idx[lenth // weight:]
	val_split = idx[:lenth // weight]
	return train_split, val_split


def get_data_transforms(data_argumentation=True):
	if data_argumentation:
		data_transforms = {
			'train': transforms.Compose([
				transforms.RandomResizedCrop(224),
				transforms.RandomHorizontalFlip(),
				transforms.ToTensor(),
				transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
			]),
			'test': transforms.Compose([
				transforms.Resize(256),
				transforms.CenterCrop(224),
				transforms.ToTensor(),
				transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
			]),
		}
	else:
		data_transforms = {
			'train': transforms.Compose([
				transforms.Resize((224, 224)),
				# transforms.CenterCrop(224),
				transforms.ToTensor(),
				transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
			]),
			'test': transforms.Compose([
				transforms.Resize((224, 224)),
				# transforms.CenterCrop(224),
				transforms.ToTensor(),
				transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
			]),
		}
	return data_transforms

data_transforms = get_data_transforms(data_argumentation=True)


def set_trainable(model, keywords):
	if 'All' in keywords:
		for name, param in model.named_parameters():
			param.requires_grad = True
	else:
		for name, param in model.named_parameters():
			param.requires_grad = False
			for k in keywords:
				if k in name:
					param.requires_grad = True


def get_trainable(model, keyword=''):
	print("==> Requires grad: ")
	params_to_update_class = []
	for name, param in model.named_parameters():
		if param.requires_grad == True and keyword in name:
			params_to_update_class.append(param)
			print("\t",name)
	return params_to_update_class


def euclidean_metric(a, b):
	n = a.shape[0]
	m = b.shape[0]
	a = a.unsqueeze(1).expand(n, m, -1)
	b = b.unsqueeze(0).expand(n, m, -1)
	dist = ((a - b)**2).sum(dim=2)
	return dist


def pl_loss(feature, label, center):
	"""
	Prototype loss
	"""
	idx = label.expand(feature.shape[1], feature.shape[0]).transpose(0, 1)
	batch_center = torch.gather(center, 0, idx)
	loss = ((feature - batch_center)**2).mean()
	return loss


def dce_loss(feat, prototype, label, weight_pl):
	"""
	distance based cross entropy loss (DCE)
	"""
	feat_logits = -euclidean_metric(feat, prototype)
	loss1 = F.cross_entropy(feat_logits, label)
	loss2 = pl_loss(feat, label, prototype)
	feat_loss = loss1 + weight_pl * loss2
	return feat_loss


def co_loss(visual, semantic, visual_prototype, semantic_prototype, label, opt):
	"""
	Co-representation learning loss
	"""
	visual_loss = dce_loss(visual, visual_prototype, label, opt.weight_pl)
	semantic_loss = dce_loss(semantic, semantic_prototype, label, opt.weight_pl)
	loss = visual_loss + semantic_loss
	return loss


def count_acc(logits, label):
	pred = torch.argmax(logits, dim=1)
	correct = torch.sum(pred == label)
	return correct.item()


# for threshold in tqdm(thresholds):
# 	acc = 0
# 	accept = 0
# 	reject = 0
# 	for idx, entropy in enumerate(visual_entropy):
# 		if entropy <= threshold:  # accept
# 			accept += 1
# 			if labels[idx].item() in seen_class and seen_fake_to_real[visual_preds[idx].item()] == labels[idx].item():
# 				acc += 1
# 		elif entropy > threshold:  # reject
# 			reject += 1
# 			if labels[idx].item() in unseen_class and unseen_fake_to_real[semantic_preds[idx].item()] == labels[
# 				idx].item():
# 				acc += 1
# 	acc /= len(dataloader.dataset)
# 	accept /= len(dataloader.dataset)
# 	reject /= len(dataloader.dataset)
# 	accuracy.append(acc)
# 	accept_rate.append(accept)
# 	reject_rate.append(reject)
def entropy_analysis(model, prototype, dataloader, thresholds, device, is_seen):
	seen_fake_to_real = dataloader.dataset.fake_to_real['trainval']
	unseen_fake_to_real = dataloader.dataset.fake_to_real['test_unseen']
	unseen_prototype = dataloader.dataset.attribute['test_unseen']
	unseen_prototype = torch.from_numpy(unseen_prototype).to(device=device, dtype=torch.float)
	model.eval()
	with torch.no_grad():
		all_visual_logits = []
		all_semantic_logits = []
		all_labels = []
		loader = tqdm(dataloader, total=len(dataloader))
		for sample in loader:
			image = sample['feature'].to(device=device, dtype=torch.float)
			label = sample['label'].to(device=device, dtype=torch.int16)
			visual, semantic = model(image)
			visual_logit = -euclidean_metric(visual, prototype)
			semantic_logit = -euclidean_metric(semantic, unseen_prototype)
			all_visual_logits.append(visual_logit)
			all_semantic_logits.append(semantic_logit)
			all_labels.append(label)
		visual_logits = torch.cat(all_visual_logits, dim=0)
		semantic_logits = torch.cat(all_semantic_logits, dim=0)
		visual_preds = torch.argmax(visual_logits, dim=1)
		semantic_preds = torch.argmax(semantic_logits, dim=1)
		
		visual_logits = F.softmax(visual_logits, dim=1)
		visual_entropy = -torch.mean(torch.log(visual_logits) * visual_logits, dim=1)
		labels = torch.cat(all_labels, dim=0)

		accuracy = []
		accept_rate = []
		for threshold in tqdm(thresholds):
			accept = np.float16((visual_entropy <= threshold).sum().item() / len(dataloader.dataset))
			idx = (visual_entropy <= threshold)
			if is_seen:
				if labels[idx].size(0) == 0:
					acc = 0
				else:
					preds = torch.tensor([np.int16(seen_fake_to_real[vp.item()]) for vp in visual_preds[idx]], device=device)
					acc = np.float16(preds.eq(labels[idx]).sum().item() / len(dataloader.dataset))
			else:
				if labels[~idx].size(0) == 0:
					acc = 0
				else:
					preds = torch.tensor([np.int16(unseen_fake_to_real[sp.item()]) for sp in semantic_preds[~idx]], device=device)
					acc = np.float16(preds.eq(labels[~idx]).sum().item() / len(dataloader.dataset))
			accuracy.append(acc)
			accept_rate.append(accept)

		reject_rate = [1 - x for x in accept_rate]
			
	return accuracy, accept_rate, reject_rate


def entropy_rejection(model, prototype, seen_loader, unseen_loader, thresholds, device):
	model.eval()
	with torch.no_grad():
		all_logits = []
		for sample in seen_loader:
			image = sample['feature'].to(device=device, dtype=torch.float)
			output = model(image)
			if isinstance(output, tuple):
				output = output[0]
			logits = -euclidean_metric(output, prototype)
			all_logits.append(logits)
		seen_logits = torch.cat(all_logits, dim=0)
		seen_logits = F.softmax(seen_logits, dim=1)
		seen_entropy = -torch.mean(torch.log(seen_logits) * seen_logits, dim=1)		# entropy

		all_logits = []
		for sample in unseen_loader:
			image = sample['feature'].to(device=device, dtype=torch.float)
			output = model(image)
			if isinstance(output, tuple):
				output = output[0]
			logits = -euclidean_metric(output, prototype)
			all_logits.append(logits)
		unseen_logits = torch.cat(all_logits, dim=0)
		unseen_logits = F.softmax(unseen_logits, dim=1)
		unseen_entropy = -torch.mean(torch.log(unseen_logits) * unseen_logits, dim=1)

	accept_rate = []
	reject_rate = []
	H = []
	for threshold in thresholds:
		seen_acc = (seen_entropy < threshold).nonzero().shape[0] / len(seen_entropy)
		accept_rate.append(seen_acc)
		unseen_rej = 1. - (unseen_entropy < threshold).nonzero().shape[0] / len(unseen_entropy)
		reject_rate.append(unseen_rej)
		H.append(2 * seen_acc * unseen_rej / (seen_acc + unseen_rej))
	return accept_rate, reject_rate, H, thresholds.tolist()


def gzsl_acc(threshold, model, prototype, dataloader, device):
	"""
	GZSL by entropy
	"""
	seen_class = dataloader.dataset.real_class['trainval']
	unseen_class = dataloader.dataset.real_class['test_unseen']
	seen_fake_to_real = dataloader.dataset.fake_to_real['trainval']
	unseen_fake_to_real = dataloader.dataset.fake_to_real['test_unseen']
	unseen_prototype = dataloader.dataset.attribute['test_unseen']
	unseen_prototype = torch.from_numpy(unseen_prototype).to(device=device, dtype=torch.float)
	model.eval()
	with torch.no_grad():
		all_visual_logits = []
		all_semantic_logits = []
		all_labels = []
		for sample in dataloader:
			image = sample['feature'].to(device=device, dtype=torch.float)
			label = sample['label'].to(device=device, dtype=torch.int64)
			visual, semantic = model(image)
			visual_logit = -euclidean_metric(visual, prototype)
			semantic_logit = -euclidean_metric(semantic, unseen_prototype)
			all_visual_logits.append(visual_logit)
			all_semantic_logits.append(semantic_logit)
			all_labels.append(label)
		visual_logits = torch.cat(all_visual_logits, dim=0)
		semantic_logits = torch.cat(all_semantic_logits, dim=0)
		visual_preds = torch.argmax(visual_logits, dim=1)
		semantic_preds = torch.argmax(semantic_logits, dim=1)

		visual_logits = F.softmax(visual_logits, dim=1)
		visual_entropy = -torch.mean(torch.log(visual_logits) * visual_logits, dim=1)
		labels = torch.cat(all_labels, dim=0)

		acc = 0
		accept = 0
		reject = 0
		for idx, entropy in enumerate(visual_entropy):
			if entropy <= threshold:  # accept
				accept += 1
				if labels[idx].item() in seen_class and seen_fake_to_real[visual_preds[idx].item()] == labels[idx].item():
					acc += 1
			elif entropy > threshold:  # reject
				reject += 1
				if labels[idx].item() in unseen_class and unseen_fake_to_real[semantic_preds[idx].item()] == labels[idx].item():
					acc += 1
		acc /= len(dataloader.dataset)
		accept /= len(dataloader.dataset)
		reject /= len(dataloader.dataset)
	return acc, accept, reject


def zsl_acc(model, dataloader, device):
	"""
	GZSL by entropy
	"""
	unseen_fake_to_real = dataloader.dataset.fake_to_real['test_unseen']
	unseen_prototype = dataloader.dataset.attribute['test_unseen']
	unseen_prototype = torch.from_numpy(unseen_prototype).to(device=device, dtype=torch.float)
	model.eval()
	with torch.no_grad():
		all_logits = []
		all_labels = []
		for sample in dataloader:
			image = sample['feature'].to(device=device, dtype=torch.float)
			label = sample['label'].to(device=device, dtype=torch.int64)
			_, semantic = model(image)
			semantic_logit = -euclidean_metric(semantic, unseen_prototype)
			all_logits.append(semantic_logit)
			all_labels.append(label)
		semantic_logits = torch.cat(all_logits, dim=0)
		semantic_preds = torch.argmax(semantic_logits, dim=1)
		labels = torch.cat(all_labels, dim=0)

		acc = 0
		for idx, pred in enumerate(semantic_preds):
			if unseen_fake_to_real[pred.item()] == labels[idx].item():
				acc += 1
		acc /= len(dataloader.dataset)
	return acc


def normal_acc(model, visual_prototype, dataloader, device):
	"""
	GZSL by entropy
	"""
	seen_fake_to_real = dataloader.dataset.fake_to_real['trainval']
	model.eval()
	with torch.no_grad():
		all_logits = []
		all_labels = []
		for sample in dataloader:
			image = sample['feature'].to(device=device, dtype=torch.float)
			label = sample['label'].to(device=device, dtype=torch.int64)
			visual, _ = model(image)
			visual_logit = -euclidean_metric(visual, visual_prototype)
			all_logits.append(visual_logit)
			all_labels.append(label)
		visual_logits = torch.cat(all_logits, dim=0)
		visual_preds = torch.argmax(visual_logits, dim=1)
		labels = torch.cat(all_labels, dim=0)

		acc = 0
		for idx, pred in enumerate(visual_preds):
			if seen_fake_to_real[pred.item()] == labels[idx].item():
				acc += 1
		acc /= len(dataloader.dataset)
	return acc

