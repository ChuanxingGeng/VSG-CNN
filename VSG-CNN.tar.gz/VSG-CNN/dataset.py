import scipy.io as sio
import torch
from torch.utils.data import Dataset
from torchvision import transforms
from PIL import Image
from sklearn import preprocessing
import numpy as np
import random
from utils import get_train_val_split

dataset_root = '../data/'
datapath = {
	'cub': dataset_root + 'GBU/CUB',
	'awa': dataset_root + 'GBU/AWA2',
	'apy': dataset_root + 'GBU/APY',
	'sun': dataset_root + 'GBU/SUN',
}
imagepath = {
	'cub': dataset_root + 'CUB_200_2011/CUB_200_2011',
	'awa': dataset_root + 'Animals_with_Attributes2/JPEGImages',
	'apy': dataset_root + 'APY',
	'sun': dataset_root + 'SUN',
}
image_file_prefix = {
	'cub': '/BS/Deep_Fragments/work/MSc/CUB_200_2011/CUB_200_2011',
	'awa': '/BS/xian/work/data/Animals_with_Attributes2//JPEGImages',
	'apy': '/BS/Deep_Fragments/work/MSc/data/APY',
	'sun': '/BS/Deep_Fragments/work/MSc/data/SUN'
}

threshold_split = {
	'cub': get_train_val_split(4702, 6),		# cub, 100 seen
	'awa': get_train_val_split(16187, 6),		# awa, 27 seen
	'apy': get_train_val_split(4906, 6),		# apy, 15 seen
	'sun': get_train_val_split(9280, 6),		# sun, 580 seen
}

gzsl_split = {
	'cub': get_train_val_split(7057, 6),		# cub, 150 seen
	'awa': get_train_val_split(23527, 6),		# awa, 40 seen
	'apy': get_train_val_split(5932, 6),		# apy, 20 seen
	'sun': get_train_val_split(10320, 6),		# sun, 645 seen
}


class GBU_Dataset(Dataset):
	def __init__(self, dataset='cub', mode='train', get_image=True,
				 image_transform=None,
				 feature_transform=True):
		"""
		GBU dataset, include CUB, AwA2, aPY
		:param dataset:
		:param mode:
		:param get_image:
		:param image_transform:
		:param feature_transform:
		"""
		self.dataset = dataset
		self.image_transform = image_transform
		self.get_image = get_image
		self.datapath = datapath[dataset]
		self.imagepath = imagepath[dataset]

		if dataset == 'apy':
			self.box_table = self._get_apy_box()

		feature, label, image_files = self._get_mat_1(self.datapath + '/res101.mat')
		attr, class_names, \
		trainval_loc, train_loc, val_loc, test_seen_loc, test_unseen_loc = self._get_mat_2(self.datapath + '/att_splits.mat')

		if feature_transform:
			scalar = preprocessing.MinMaxScaler()
			scalar.fit(feature[trainval_loc])
			feature = scalar.transform(feature)

		self.class_names = class_names
		self.real_class = {
			'all': np.unique(label),		# 200 classes
			'train': np.unique(label[train_loc]),		# 100 classes
			'trainval': np.unique(label[trainval_loc]),		# 150 classes
			'val': np.unique(label[val_loc]),		# 50 classes
			'test_unseen': np.unique(label[test_unseen_loc]),		# 50 classes
		}
		self.prototype_num = self.real_class['trainval'].shape[0]
		self.prototype_num_for_threshold = self.real_class['train'].shape[0]
		self.attribute_dim = attr.shape[1]

		self.real_to_fake = {
			'all': dict((r, f) for f, r in enumerate(self.real_class['all'])),
			'train': dict((r, f) for f, r in enumerate(self.real_class['train'])),
			'trainval': dict((r, f) for f, r in enumerate(self.real_class['trainval'])),
			'val': dict((r, f) for f, r in enumerate(self.real_class['val'])),
			'test_unseen': dict((r, f) for f, r in enumerate(self.real_class['test_unseen'])),
		}
		self.fake_to_real = {
			'all': dict((f, r) for f, r in enumerate(self.real_class['all'])),
			'train': dict((f, r) for f, r in enumerate(self.real_class['train'])),
			'trainval': dict((f, r) for f, r in enumerate(self.real_class['trainval'])),
			'val': dict((f, r) for f, r in enumerate(self.real_class['val'])),
			'test_unseen': dict((f, r) for f, r in enumerate(self.real_class['test_unseen'])),
		}

		self.attribute = {
			'all': attr[self.real_class['all']],
			'train': attr[self.real_class['train']],
			'trainval': attr[self.real_class['trainval']],
			'val': attr[self.real_class['val']],
			'test_unseen': attr[self.real_class['test_unseen']],
		}

		if mode == 'train':  	# 100 classes
			self.feature = feature[train_loc]
			self.label = label[train_loc]
			temp = [self.real_to_fake['train'][f] for f in self.label]
			self.label = np.asarray(temp)
			self.image_files = image_files[train_loc]
			self.loc = train_loc
		elif mode == 'train_for_threshold' or mode == 'val_for_threshold':  # 100 classes
			if mode == 'train_for_threshold':
				train_split = threshold_split[self.dataset][0]
			else:
				train_split = threshold_split[self.dataset][1]

			train_loc = np.intersect1d(trainval_loc, train_loc)
			train_for_threshold_loc = train_loc[train_split]
			self.feature = feature[train_for_threshold_loc]
			self.label = label[train_for_threshold_loc]
			temp = [self.real_to_fake['train'][f] for f in self.label]
			self.label = np.asarray(temp)
			self.image_files = image_files[train_for_threshold_loc]
			self.loc = train_for_threshold_loc
		elif mode == 'val':  # 50 classes
			self.feature = feature[val_loc]
			self.label = label[val_loc]
			self.image_files = image_files[val_loc]
			self.loc = val_loc
		elif mode == 'trainval':  # 150 classes
			self.feature = feature[trainval_loc]
			self.label = label[trainval_loc]
			temp = [self.real_to_fake['trainval'][f] for f in self.label]
			self.label = np.asarray(temp)
			self.image_files = image_files[trainval_loc]
			self.loc = trainval_loc
		elif mode == 'train_for_gzsl' or mode == 'val_for_gzsl':		# 150 classes
			if mode == 'train_for_gzsl':
				train_split = gzsl_split[self.dataset][0]
			else:
				train_split = gzsl_split[self.dataset][1]
			train_for_gzsl_loc = trainval_loc[train_split]
			self.feature = feature[train_for_gzsl_loc]
			self.label = label[train_for_gzsl_loc]
			temp = [self.real_to_fake['trainval'][f] for f in self.label]
			self.label = np.asarray(temp)
			self.image_files = image_files[train_for_gzsl_loc]
			self.loc = train_for_gzsl_loc
		elif mode == 'test_seen':  # 150 classes
			self.feature = feature[test_seen_loc]
			self.label = label[test_seen_loc]
			self.image_files = image_files[test_seen_loc]
			self.loc = test_seen_loc
		elif mode == 'test_unseen':  # 50 classes
			self.feature = feature[test_unseen_loc]
			self.label = label[test_unseen_loc]
			self.image_files = image_files[test_unseen_loc]
			self.loc = test_unseen_loc
		elif mode == 'all':
			self.feature = feature
			self.label = label
			self.image_files = image_files
			self.loc = np.arange(len(feature))
		else:
			raise Exception('Dataset mode error!')

		self.len = len(self.label)

	def _get_mat_1(self, matpath):
		matcontent = sio.loadmat(matpath)
		feature = matcontent['features'].T.astype(float)
		label = matcontent['labels'].astype(int).squeeze() - 1
		image_files = matcontent['image_files'].squeeze()
		for idx in range(image_files.shape[0]):
			image_files[idx] = image_files[idx][0].replace(image_file_prefix[self.dataset],
														   self.imagepath)
		return feature, label, image_files

	def _get_mat_2(self, matpath):
		matcontent = sio.loadmat(matpath)
		attr = matcontent['att'].T.astype(float)
		class_names = matcontent['allclasses_names'].squeeze()
		trainval_loc = matcontent['trainval_loc'].squeeze() - 1
		train_loc = matcontent['train_loc'].squeeze() - 1
		val_loc = matcontent['val_loc'].squeeze() - 1
		test_seen_loc = matcontent['test_seen_loc'].squeeze() - 1
		test_unseen_loc = matcontent['test_unseen_loc'].squeeze() - 1
		return attr, class_names, trainval_loc, train_loc, val_loc, test_seen_loc, test_unseen_loc

	def _get_apy_box(self):
		boxroot = '../data/APY/attribute_data/'
		filename1 = boxroot + 'apascal_train.txt'
		filename2 = boxroot + 'apascal_test.txt'
		filename3 = boxroot + 'ayahoo_test.txt'
		import pandas
		df1 = pandas.read_table(filename1, header=None, sep=' ')
		df2 = pandas.read_table(filename2, header=None, sep=' ')
		df3 = pandas.read_table(filename3, header=None, sep=' ')
		df = pandas.concat([df1, df2, df3])
		table = df.loc[:, 0:5].values[:, [0, 2, 3, 4, 5]]
		return table

	def _crop_image(self, image, idx):
		bbox = self.box_table[self.loc[idx]][1:]
		if bbox[0] == bbox[2] or bbox[1] == bbox[3]:
			raise Exception('Label error on bounding box! A wrong box for image file: {}'.format(self.image_files[idx]))
		cropped_img = image.crop(tuple(bbox))
		return cropped_img

	def __len__(self):
		return self.len

	def __getitem__(self, idx):
		feature = self.feature[idx]
		label = self.label[idx]
		feature = torch.from_numpy(feature)
		label = torch.as_tensor(int(label))

		if self.get_image:
			img_path = self.image_files[idx]
			with open(img_path, 'rb') as f:
				image = Image.open(f)
				image = image.convert('RGB')
			if self.dataset == 'apy':
				image = self._crop_image(image, idx)
			if self.image_transform:
				image = self.image_transform(image)
			sample = {
				'feature': image,
				'label': label
			}
		else:
			sample = {
				'feature': feature,
				'label': label
			}
		return sample

	def __repr__(self):
		fmt_str = 'Dataset ' + self.__class__.__name__ + ' ({})\n'.format(self.dataset)
		fmt_str += '    Number of datapoints: {}\n'.format(self.__len__())
		fmt_str += '    Root Location: {}\n'.format(self.datapath)
		tmp = '    Image transforms (if any): '
		fmt_str += '{0}{1}\n'.format(tmp, self.image_transform.__repr__().replace('\n', '\n' + ' ' * len(tmp)))
		tmp = '    Feature Transforms (if any): '
		fmt_str += '{0}{1}'.format(tmp, 'True\n'.replace('\n', '\n' + ' ' * len(tmp)))
		return fmt_str


def test():
	# Data argumentation
	data_transforms = {
		'train': transforms.Compose([
			transforms.RandomResizedCrop(224),
			transforms.RandomHorizontalFlip(),
			transforms.ToTensor(),
			transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
		]),
		'test': transforms.Compose([
			transforms.Resize(224),
			transforms.CenterCrop(224),
			transforms.ToTensor(),
			transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
		]),
	}

	# data_transforms = {
	# 	'train': transforms.Compose([
	# 		transforms.Resize(224),
	# 		transforms.CenterCrop(224),  # This is indispensable
	# 		transforms.ToTensor(),
	# 		transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
	# 	]),
	# 	'test': transforms.Compose([
	# 		transforms.Resize(224),
	# 		transforms.CenterCrop(224),  # This is indispensable
	# 		transforms.ToTensor(),
	# 		transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
	# 	]),
	# }

	import time

	dataset = GBU_Dataset(dataset='apy', mode='train_for_gzsl', get_image=True, image_transform=data_transforms['train'])
	# dataloader = torch.utils.data.DataLoader(dataset, batch_size=64, shuffle=False)
	#
	# time_start = time.time()
	# for batch_idx, sample in enumerate(dataloader):
	# 	image = sample['feature']
	# 	label = sample['label']
	# 	if batch_idx == 100:
	# 		break
	# time_end = time.time()
	# print('Time cost', time_end - time_start, 's')

	dataloader = torch.utils.data.DataLoader(dataset, batch_size=64, shuffle=True, num_workers=1, pin_memory=True)

	time_start = time.time()
	for batch_idx, sample in enumerate(dataloader):
		image = sample['feature']
		label = sample['label']
		if batch_idx == 100:
			break
	time_end = time.time()
	print('Time cost', time_end - time_start, 's')

	dataloader = torch.utils.data.DataLoader(dataset, batch_size=64, shuffle=True, num_workers=5, pin_memory=True)

	time_start = time.time()
	for batch_idx, sample in enumerate(dataloader):
		image = sample['feature']
		label = sample['label']
		if batch_idx == 100:
			break
	time_end = time.time()
	print('Time cost', time_end - time_start, 's')

	dataloader = torch.utils.data.DataLoader(dataset, batch_size=64, shuffle=True, num_workers=8, pin_memory=True)

	time_start = time.time()
	for batch_idx, sample in enumerate(dataloader):
		image = sample['feature']
		label = sample['label']
		if batch_idx == 100:
			break
	time_end = time.time()
	print('Time cost', time_end - time_start, 's')


	return 0

if __name__ == '__main__':
	test()


